package com.example.nando.hotel;

import android.app.Activity;
import android.os.Bundle;

import com.example.nando.hotel.R;

public class NovaSenhaActivity extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_senha);
    }
}
